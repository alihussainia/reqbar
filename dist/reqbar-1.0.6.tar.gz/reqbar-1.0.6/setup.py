from setuptools import setup

setup(
    name= 'reqbar',
    version='1.0.6',
    description="To install python package requirements with a bar rather logs!",
    packages=['reqbar'],
    author='Muhammad Ali',
    author_email='malirashid1994@gmail.com',
    zip_safe=False)